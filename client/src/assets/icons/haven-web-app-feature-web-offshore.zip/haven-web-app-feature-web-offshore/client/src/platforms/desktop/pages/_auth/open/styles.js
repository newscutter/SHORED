import styled from "styled-components";

export const Body = styled.div`
  height: auto;
  width: auto;
  margin: 10px;
`;

export const Wrapper = styled.div`
  height: 100%;
  width: auto;
`;
