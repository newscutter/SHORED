export const ExchangeFees = [
  { name: "Default", ticker: "Unlocks ~7d", percent: "0.2%", prio: 0 },
  { name: "Low", ticker: "Unlocks ~48h", percent: "5%", prio: 1 },
  { name: "Medium", ticker: "Unlocks ~24hr", percent: "10%", prio: 2 },
  { name: "High", ticker: "Unlocks ~6hr", percent: "20%", prio: 3 },
];
