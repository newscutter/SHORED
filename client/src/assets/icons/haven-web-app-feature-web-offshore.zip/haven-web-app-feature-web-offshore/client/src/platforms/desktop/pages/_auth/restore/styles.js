import styled from "styled-components";

export const Body = styled.div`
  height: 264px;
  width: auto;
  margin: 10px;
`;

export const Wrapper = styled.div`
  height: 100%;
  width: auto;
  margin-bottom: 10px;
`;
