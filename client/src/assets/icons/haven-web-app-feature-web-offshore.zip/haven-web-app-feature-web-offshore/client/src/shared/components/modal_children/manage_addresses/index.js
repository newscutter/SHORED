// Library Imports
import React, { Fragment } from "react";
import Description from "shared/components/_inputs/description";
import Input from "shared/components/_inputs/input";

// Relative Imports

const ManageAddresses = ({ children }) => {
  return <Fragment>{children}</Fragment>;
};

export default ManageAddresses;
