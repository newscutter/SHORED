import { Component } from "react";
import React from "react";
import { CreateWebComponent } from "platforms/web/pages/_auth/create/multi-create";

export class CreateWeb extends Component<{}, {}> {
  render() {
    return <CreateWebComponent />;
  }
}
