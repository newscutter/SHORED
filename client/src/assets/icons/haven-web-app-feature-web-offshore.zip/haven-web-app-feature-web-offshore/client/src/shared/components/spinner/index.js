import { Circle } from "./styles";
import React from "react";

export const Spinner = () => {
  return <Circle />;
};
